// Simple smoke test – run with: node server.test.js
const { WebSocket } = require('ws');

const server = require('./server');

setTimeout(() => {
  const ws = new WebSocket('ws://localhost:3001');

  ws.on('open', () => {
    console.log('✅ Connected to WebSocket server');
    ws.send(JSON.stringify({ type: 'SUBSCRIBE', pairs: ['BTC/USDT'] }));
  });

  ws.on('message', (data) => {
    const msg = JSON.parse(data);
    if (msg.type === 'SUBSCRIBED') {
      console.log('✅ Subscription confirmed:', msg.pairs);
    }
    if (msg.type === 'PRICE_UPDATE') {
      console.log('✅ Price update received:', msg.data[0]);
      ws.close();
      process.exit(0);
    }
  });

  ws.on('error', (err) => {
    console.error('❌ Error:', err.message);
    process.exit(1);
  });
}, 500);
