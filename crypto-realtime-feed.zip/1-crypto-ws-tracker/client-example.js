// ── Test client – run with: node client-example.js ──
const { WebSocket } = require('ws');

const ws = new WebSocket('ws://localhost:3001');

ws.on('open', () => {
  console.log('[CLIENT] Connected');
  // Subscribe to specific pairs only
  ws.send(JSON.stringify({ type: 'SUBSCRIBE', pairs: ['BTC/USDT', 'ETH/USDT'] }));
});

ws.on('message', (data) => {
  const msg = JSON.parse(data);
  if (msg.type === 'PRICE_UPDATE') {
    console.table(msg.data.map(d => ({
      pair: d.pair,
      price: d.price,
      change24h: `${d.change24h}%`
    })));
  }
});

ws.on('error', console.error);
