# 🔌 Real-time Crypto Price Tracker

WebSocket server that streams live price ticks with per-client subscription filtering.

## Features
- **WebSocket feed** – 500ms ticks per subscribed pair
- **Subscription model** – clients choose pairs via SUBSCRIBE/UNSUBSCRIBE messages
- **REST snapshot** – `GET /api/prices` for HTTP fallback
- **Health endpoint** – `GET /health`

## Run
```bash
npm install
npm run dev
```

## Protocol
| Message (client → server) | Payload |
|---|---|
| `SUBSCRIBE` | `{ type, pairs: ["BTC/USDT"] }` |
| `UNSUBSCRIBE` | `{ type, pairs: [...] }` |
| `PING` | `{ type }` |

| Message (server → client) | Payload |
|---|---|
| `PRICE_UPDATE` | `{ type, ts, data: [{pair, price, change24h}] }` |
| `PONG` | `{ type, ts }` |
| `ERROR` | `{ type, message }` |

## Production notes
- Replace `simulateMarket()` with real Binance/OKX WebSocket connection
- Add Redis pub/sub for horizontal scaling
- Add authentication middleware before `wss.on('connection')`
